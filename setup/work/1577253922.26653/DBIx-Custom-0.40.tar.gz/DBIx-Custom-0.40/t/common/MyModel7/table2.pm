package MyModel7::table2;

use base 'MyModel7';

1;
