package MyModel6::table2;

use base 'MyModel6';

1;
