package MyModel8;
use DBIx::Custom::Model -base;

1;
