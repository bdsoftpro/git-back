package MyModel6::TABLE2;

use base 'MyModel6';

1;
