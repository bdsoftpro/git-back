package MyModel6::main::table2;

use base 'MyModel6';

1;
