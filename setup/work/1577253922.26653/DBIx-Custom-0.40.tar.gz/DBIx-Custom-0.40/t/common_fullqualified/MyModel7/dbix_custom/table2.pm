package MyModel7::dbix_custom::table2;

use base 'MyModel7';

1;
