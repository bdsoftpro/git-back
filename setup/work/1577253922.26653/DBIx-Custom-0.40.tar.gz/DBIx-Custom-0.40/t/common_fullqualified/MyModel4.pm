package MyModel4;

use base 'DBIx::Custom::Model';

1;
