package MyModel7;

use base 'DBIx::Custom::Model';

1;
