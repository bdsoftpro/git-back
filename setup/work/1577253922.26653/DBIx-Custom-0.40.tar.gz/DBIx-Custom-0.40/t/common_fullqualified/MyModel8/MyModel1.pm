package MyModel8::MyModel1;

use base 'DBIx::Custom::Model';

1;
