package MyModel5;

use base 'DBIx::Custom::Model';

1;
